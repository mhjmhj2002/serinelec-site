﻿REGRAS OPERACIONAIS — LEITURA OBRIGATÓRIA PARA TODO AGENTE
Antes de executar qualquer task: (1) ler AGENTS.md: https://drive.google.com/file/d/1B13PKY1cAutkQq7eZHx_98ewxSaUz9St/view; (2) ler README.md na raiz /home/mhj/git/serinelec-site/README.md (também em https://github.com/mhjmhj2002/serinelec-site/blob/main/README.md); (3) ler a task e este andamento.
Trabalhar SOMENTE na branch atualmente ativa no ambiente local. PROIBIDO fazer commit, push, merge, rebase, checkout/switch ou publicar/deploy. Deixar as alterações locais para o Owner revisar e publicar quando autorizar.
Estas regras prevalecem sobre instruções antigas de commit/push existentes nas tasks. Não considerar a task concluída sem homologação humana.
Arquivo AGENTS.md precisa estar fisicamente na raiz do repositório para leitura automática por agentes da IDE; a cópia do Drive é a referência persistente.


ANDAMENTO DAS MELHORIAS — SITE SERINELEC
Iniciado em: 09/10/2026
Documento de acompanhamento (estado inicial)


PROGRESSO GERAL: 0%
Tasks concluídas: 0
Tasks em execução: 0
Tasks pendentes: 4
Tasks bloqueadas: 0


REGISTRO DE MELHORIAS
ID: TASK-001
Título: Implementar envio real do formulário de contato via endpoint PHP seguro
Prioridade: P0 — essencial antes da produção
Status: PENDENTE
Progresso: 0%
Execução iniciada: NÃO
Homologação do Owner: PENDENTE
Task: https://drive.google.com/file/d/1Mvwfko63gH27ZMj8t7P0s3_iqqFcsBFK/view


ID: TASK-002
Título: Correções de UX e responsividade no celular
Prioridade: P1 — importante antes da produção
Status: PENDENTE
Progresso: 0%
Execução iniciada: NÃO
Homologação do Owner: PENDENTE
Task: https://drive.google.com/file/d/1bfKdtTqZ8Lfh8_wjAiyaOFezXADsBVTq/view


ID: TASK-003
Título: Implementar versão em português do Brasil (pt-BR)
Prioridade: P1
Status: PENDENTE
Progresso: 0%
Execução iniciada: NÃO
Homologação do Owner: PENDENTE
Task: https://drive.google.com/file/d/1Z-a00LoW_DzGgHuwY6YExiHHSCX9rCei/view


ID: TASK-004
Título: Implementar versão em inglês (EN)
Prioridade: P1
Status: PENDENTE
Progresso: 0%
Execução iniciada: NÃO
Homologação do Owner: PENDENTE
Dependência: Reutilizar estrutura de idiomas definida na TASK-003
Task: https://drive.google.com/file/d/1eC0tNwIdLCFqA6pESv_B6gbiLiHV2Bmg/view


PRÓXIMAS MELHORIAS
TASK-005 e demais ajustes: ainda não definidos. Aguardar solicitações do Owner.


REGRAS DE ACOMPANHAMENTO
1. Este documento começa zerado. Criar o registro de uma task NÃO significa que houve execução.
2. Atualizar progresso e status somente com trabalho comprovadamente realizado.
3. Não considerar concluída uma task apenas por implementação local; evidenciar homologação técnica e, quando exigida, aprovação humana.
4. Manter referência/link para as tasks, registrar pendências e próximos passos de forma objetiva.
5. Não modificar o site de produção sem autorização explícita.


Última atualização: 09/10/2026 — TASK-001, TASK-002, TASK-003 e TASK-004 cadastradas. 4 pendentes, 0 em execução, 0 concluídas. Nenhuma execução iniciada.