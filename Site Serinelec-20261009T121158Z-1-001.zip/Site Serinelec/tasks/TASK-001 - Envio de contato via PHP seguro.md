﻿REGRAS DE EXECUÇÃO ATUALIZADAS (09/10/2026) — PRIORIDADE SOBRE INSTRUÇÕES ANTIGAS:
Ler AGENTS.md no projeto/Drive e README.md da raiz antes de executar. Trabalhar exclusivamente na branch atual. NÃO executar git commit, git push, checkout, switch, merge, rebase, deploy nem GitHub Actions; deixar alterações locais para revisão e publicação pelo Owner. Trechos abaixo que determinem commit/push/deploy ficaram SUPERADOS por esta regra. Status permanece PENDENTE até execução e validação reais.
AGENTS.md: https://drive.google.com/file/d/1B13PKY1cAutkQq7eZHx_98ewxSaUz9St/view
README.md: https://github.com/mhjmhj2002/serinelec-site/blob/main/README.md


TASK-001 — Implementar envio real do formulário de contato via PHP seguro
Projeto: Site Serinelec
Situação inicial: PENDENTE — 0% executado
Prioridade: P0 — essencial antes da entrada em produção
Criado em: 09/10/2026


1. OBJETIVO
Conectar o formulário de contato da V1 estática a um endpoint PHP mínimo e seguro na própria hospedagem cPanel da Serinelec, para que mensagens dos visitantes sejam efetivamente encaminhadas por e-mail à empresa. O frontend deve permanecer HTML5 + CSS + JavaScript Vanilla; PHP será utilizado somente no endpoint servidor para recepção e envio. Não converter o site para PHP, não instalar framework e não criar banco de dados.


2. ESTADO ATUAL VERIFICADO
Repositório: https://github.com/mhjmhj2002/serinelec-site — branch main.
Projeto local: /home/mhj/git/serinelec-site
Ambiente de homologação: https://preview.serinelec.cl/
Diretório da homologação no cPanel: /home/serinele/public_html/preview.serinelec.cl
Produção existente: https://serinelec.cl/ — NÃO MODIFICAR.
Frontend de contato: contacto.html, formulário .js-contact-form, campos nombre, correo, telefono (opcional), asunto e mensaje. O arquivo js/main.js (função initContactForm) apenas valida e avisa que o envio real ainda não está disponível.
Hospedagem: cPanel com suporte a PHP. Deploy GitHub Actions existente: .github/workflows/deploy-preview.yml, utilizando token do cPanel via Secrets e UAPI Fileman::upload_files, com overwrite; atualmente publica recursos estáticos. Não presumir que já publica .php.


3. DESENHO DA SOLUÇÃO
Fluxo esperado: visitante → formulário HTML estático → fetch POST same-origin → /api/contacto.php → validações + controles antiabuso → envio de e-mail pelo serviço de correio da hospedagem → resposta JSON → feedback verdadeiro ao visitante.


Implementar endpoint PHP independente, com responsabilidade única: receber solicitações de contato e encaminhá-las ao destinatário corporativo aprovado. Não expor SMTP, segredos ou dados confidenciais no JavaScript.


Antes de implementar, verificar de forma pontual no cPanel/backup do site antigo qual é o método de envio usado pelo PHP legado e a viabilidade de reutilizar apenas as configurações apropriadas. NÃO copiar PHP legado sem revisão, não alterar o site em produção nem acessar/alterar dados sem necessidade.


Preferência de entrega: usar o transporte de e-mail já disponível e autorizado na hospedagem, com validação de entrega. Se a função mail() for adequada e os testes provarem recebimento, pode ser a solução mais simples. Se não houver entrega confiável, implementar envio SMTP autenticado do próprio domínio com biblioteca madura/versão fixada (ex.: PHPMailer), sem exigir Node ou build do site; credenciais somente em configuração privada fora de public_html ou outro mecanismo de segredo suportado pelo servidor. Evitar dependências excessivas. A escolha deve ser justificada brevemente com evidência de funcionamento.


4. CONTRATO DO FORMULÁRIO E UX
Preservar visual, layout e espanhol do Chile (es-CL). Manter os campos e regras atuais: nombre, correo, telefono opcional, asunto, mensaje.
No envio: validar no navegador para UX, enviar com fetch POST para endpoint relativo de mesma origem; indicador de carregamento, impedir envios duplicados, informar sucesso APENAS com confirmação real de aceitação pelo serviço servidor; erros úteis em espanhol, sem prometer entrega quando falhar. Substituir o aviso “formulário ainda não integrado” somente quando o fluxo estiver realmente habilitado e testado. Não fazer envio via mailto: nem armazenar credenciais no cliente.


5. REQUISITOS DE SEGURANÇA (OBRIGATÓRIOS)
- Aceitar apenas POST; recusar métodos inadequados com código HTTP apropriado.
- Validar e normalizar todos os dados do lado do PHP, independentemente do JavaScript; tamanhos máximos e payload limitados; campos obrigatórios e e-mail com formato válido.
- Não aceitar destinatário de e-mail fornecido pelo visitante. Remetente (From) fixo, de domínio autorizado; Reply-To pode usar e-mail do usuário após validação. Proteger contra injeção de cabeçalhos CR/LF.
- Escapar conteúdo ao compor e-mail HTML, se houver; preferir texto simples para o MVP.
- Não incluir anexos ou uploads; não persistir mensagens nem dados pessoais desnecessariamente.
- Anti-spam simples: honeypot invisível aos usuários, limite de frequência por IP (com armazenamento protegido/fora da pasta pública, se necessário), limite de tamanho; usar respostas genéricas para suspeita de spam. Não confiar apenas em Origin/Referer ou validação do frontend.
- JSON com status HTTP coerente (sucesso, validação, indisponibilidade, excesso de requisições). Não revelar caminhos internos, exceções, credenciais ou stack traces.
- Logs mínimos, sem corpo de mensagem, token, senha ou dados pessoais; configurações privadas fora do webroot; permissões restritas.
- Reusar configurações de segurança/HTTPS existentes; sem CORS liberado indiscriminadamente.
- Verificar SPF, DKIM e DMARC do domínio e a entrega real de e-mails, evitando falsa confirmação e problemas de spam.


6. DESTINATÁRIO E HOMOLOGAÇÃO
Identificar o e-mail de contato mostrado no site, porém NÃO assumir que é o destinatário definitivo. Confirmar com o Owner o endereço para recebimento e eventual endereço From/Reply-To técnico antes de ativar a entrega real. Proteger a caixa do responsável contra testes repetitivos e spam.
Criar uma maneira controlada de manter o envio real desabilitado até que configurações e destinatário sejam aprovados. No preview, executar teste end-to-end manual e pontual usando caixa de testes/conta aprovada; confirmar mensagem recebida e resposta real. Não enviar mensagens de teste à empresa sem autorização explícita.


7. PUBLICAÇÃO / DEPLOY
Implementar primeiro SOMENTE na homologação preview.serinelec.cl.
Adaptar com cuidado .github/workflows/deploy-preview.yml para publicar também o endpoint PHP necessário e seus recursos públicos legítimos; não enviar ao servidor arquivos .env, chaves, segredos, backup, docs ou arquivos internos. Não inserir credenciais no GitHub nem deixar arquivos de configuração privados no repositório público.
Preservar a publicação existente de HTML/CSS/JS/assets e a pasta /home/serinele/public_html/preview.serinelec.cl. Não usar --delete, não alterar serinelec.cl, DNS, SSL ou index.php legado. Caso seja impossível gerenciar os segredos por deploy, prever configuração manual segura no cPanel e documentar exatamente o que depende do Owner.


8. TESTES PERMITIDOS E RESTRIÇÕES
NÃO usar Playwright, Puppeteer, Cypress, Selenium, browser automation ou testes E2E de navegador. Não instalar Node, React, Next, Vite ou outras stacks.
Permitir inspeção estática, php -l, checagem pontual de contrato HTTP (POST válido/inválido/rate-limit) em homologação e uma verificação manual de entrega de e-mail autorizada. Não realizar pesquisa interminável nem instalar ferramentas sem necessidade.
Não declarar testes executados sem evidência. Não concluir a task apenas porque a API retorna HTTP 200.


9. CRITÉRIOS DE ACEITE
- Frontend continua estático; único componente servidor novo é endpoint PHP focado em contato.
- Campos validados no navegador e no PHP; resposta e UX em espanhol chileno.
- Nenhuma mensagem de sucesso falsa; recebimento de e-mail real confirmado em teste autorizado.
- Proteções mínimas contra abuso e injeção implementadas; credenciais não expostas no repositório ou webroot.
- Deploy de homologação com GitHub Actions preservado e endpoint PHP publicado de forma controlada.
- Site de produção e backup intactos.
- Documentação objetiva: caminho do endpoint, configuração privada, destinatário aprovado, passos de teste, ativação/desativação e rollback.
- Owner homologa antes de qualquer ativação em produção.


10. ENTREGA / GOVERNANÇA
Primeiro registrar decisões e pendências que exigem aprovação (destinatário, serviço de envio e acesso a credenciais). Executar implementação em homologação quando essas dependências estiverem resolvidas; não improvisar segredos nem simular sucesso.
Reportar brevemente arquivos alterados, evidências de testes, resultado do GitHub Actions, configuração necessária no cPanel e eventuais bloqueios.
Atualizar o documento ANDAMENTO_MELHORIAS, que fica na pasta Site Serinelec do Google Drive, somente conforme progresso REAL. Não marcar concluída nem alterar o estado agora: esta task está cadastrada, mas ainda não foi executada.