﻿REGRAS DE EXECUÇÃO ATUALIZADAS (09/10/2026) — PRIORIDADE SOBRE INSTRUÇÕES ANTIGAS:
Ler AGENTS.md no projeto/Drive e README.md da raiz antes de executar. Trabalhar exclusivamente na branch atual. NÃO executar git commit, git push, checkout, switch, merge, rebase, deploy nem GitHub Actions; deixar alterações locais para revisão e publicação pelo Owner. Trechos abaixo que determinem commit/push/deploy ficaram SUPERADOS por esta regra. Status permanece PENDENTE até execução e validação reais.
AGENTS.md: https://drive.google.com/file/d/1B13PKY1cAutkQq7eZHx_98ewxSaUz9St/view
README.md: https://github.com/mhjmhj2002/serinelec-site/blob/main/README.md


TASK-003 — Implementar versão completa em português do Brasil (pt-BR)
Projeto: Site Serinelec — https://preview.serinelec.cl/
Prioridade: P1 — planejada para evolução pré-produção
Status: PENDENTE | Execução: NÃO INICIADA | Progresso: 0%
Data de cadastro: 09/10/2026
Repositório: https://github.com/mhjmhj2002/serinelec-site
Projeto local: /home/mhj/git/serinelec-site


1. OBJETIVO
Adicionar idioma Português do Brasil (pt-BR) ao site institucional da Serinelec, com navegação funcional e cobertura integral das páginas. Manter o espanhol chileno (es-CL) como versão original e padrão. Não criar um site isolado/desconectado nem substituir conteúdo espanhol.


2. INVENTÁRIO EXISTENTE
Arquivos da versão original: index.html, capacitaciones.html, gestion-produccion.html, inspecciones.html, proyectos-electricos.html, contacto.html.
Interface: seletor de idiomas .js-lang-selector e opções atualmente desabilitadas, em index.html e demais páginas; menu mobile em .js-mobile-drawer. Lógica JS em js/main.js. Estilos em css/. O projeto é HTML5/CSS3/JS Vanilla, sem framework e sem build.
Deploy preview existente via GitHub Actions/cPanel UAPI: .github/workflows/deploy-preview.yml, atualmente seleciona principalmente arquivos HTML da raiz, css/js/assets. É obrigatório considerar novas subpastas e atualizar o deploy para elas, sem ampliar publicação a arquivos privados.


3. ESTRATÉGIA ESTÁTICA
Escolher rota simples e consistente, preferencialmente /pt-br/index.html e outras cinco páginas sob /pt-br/, mantendo o espanhol na raiz atual. Reutilizar CSS, JS, imagens e componentes visuais sem duplicar assets desnecessariamente. Usar caminhos corretos de links, imagens e scripts ao navegar entre diretórios. Não implementar mecanismo de traduções carregadas exclusivamente por JS: o conteúdo principal de cada página traduzida deve existir em HTML estático e ser indexável.
Criar um mapa de equivalência página/idioma para preservar a página atual quando alguém muda entre ES e PT. Ex.: /capacitaciones.html → /pt-br/capacitaciones.html e vice-versa; usar rotas estáveis e links adequados nos menus. Não produzir links 404. Definir antecipadamente um padrão compartilhado com a TASK-004 de inglês para evitar soluções de internacionalização conflitantes.


4. TRADUÇÃO E CONTEÚDO
Traduzir completamente textos visíveis e de acessibilidade em seis páginas: hero/carrossel, menus, menu mobile, seções, clientes, cards de serviços, CTAs, formulários, validações e mensagens JS, rodapé, placeholders, labels, alt de imagens, aria-labels, titles e mensagens de status.
Usar pt-BR brasileiro profissional, natural, não tradução literal artificial. Preservar identidade, serviços, contatos, empresas, clientes, normas e referências técnicas do Chile. Manter terminologia legal chilena (SEC, TE1, ITO, etc.) conforme o contexto e acrescentar explicação curta quando necessária para leitores brasileiros, sem inventar equivalências regulatórias brasileiras.
Não inventar clientes, certificações, serviços, anos de experiência ou promessas comerciais. Não reintroduzir alegação de “orçamento grátis”; usar “Solicitar orçamento”, sem alegar gratuidade ou cobrança. O cliente é uma empresa chilena, mesmo na tradução portuguesa.


5. SELETOR E NAVEGAÇÃO
Habilitar 🇧🇷 Português no seletor de idiomas desktop e mobile. 🇨🇱 Español permanece habilitado. 🇺🇸 English continua indisponível até a TASK-004; identificar “Em breve” de modo acessível. Indicar visualmente idioma atual e usar aria-current apropriado; idioma HTML lang=pt-BR nas páginas brasileiras e lang=es-CL na versão original.
Não ocultar seletor dentro do hamburger em mobile. Trabalhar em conjunto com correções previstas na TASK-002; quando executar, inspecionar primeiro se a TASK-002 já alterou menu e adaptar sem regressão. Garantir centralização dos CTAs e layout responsivo com textos mais longos em pt-BR.


6. SEO
Títulos e meta descriptions em português para cada página; canonical correto; hreflang es-CL e pt-BR somente para as páginas existentes e acessíveis, podendo preparar en sem publicar referência inexistente. Alinhar open graph/metadados quando houver; manter URLs de cada idioma em correspondência, sem redirecionamento automático por IP ou localização.


7. FORMULÁRIO DE CONTATO / DEPENDÊNCIAS
Traduzir rótulos, mensagens e UX da página de contato. A TASK-001 prevê endpoint PHP para envio real. Se ainda não estiver concluída, manter mensagem honesta de indisponibilidade e não simular envio. Se estiver concluída, reutilizar o mesmo endpoint seguro configurado para os idiomas, preservando validações e respondendo mensagens traduzidas sem copiar segredos. Não criar outro backend.


8. DEPLOY E SEGURANÇA
Adaptar com mínimo necessário workflow de homologação para publicar /pt-br/** e futuros arquivos de idioma, sem enviar .local, docs, .git, backup, chaves, .env ou dados de configuração. Priorizar assets e HTML por último. Não alterar o servidor de produção nem usar exclusão automática. Usar preview.serinelec.cl para homologação humana.


9. VERIFICAÇÃO E CRITÉRIOS DE ACEITE
Cobertura das seis páginas em pt-BR, sem trechos genéricos em espanhol por descuido (exceto nomes próprios e termos técnicos chilenos).
Seletor ES/PT funcional nas duas direções, preservando contexto/página, inclusive mobile. EN continua marcado como futuro.
Links, caminhos e imagens corretos em diretórios diferentes, sem referência quebrada.
Texto e CTAs responsivos, navegação por teclado, lang/metadados atualizados.
Site estático sem Node, npm, PHP no frontend, frameworks ou build; PHP da TASK-001 é exceção apenas para envio do formulário.
NÃO usar Playwright, Cypress, Puppeteer, Selenium, browser automation, testes visuais automáticos, ou testes E2E. Apenas verificações estáticas básicas e avaliação manual pelo Owner.
Não marcar conclusão antes de homologação humana. Somente quando execução for autorizada, implementar, comitar, push na main e confirmar deploy de preview conforme permissões.


10. ENTREGA / ESTADO
Documento cadastrado para execução futura; não executar agora. Ao executar, relatar estrutura de idiomas, páginas entregues, arquivos alterados, deploy e pendências. Atualizar ANDAMENTO_MELHORIAS com avanço real e não presumido.