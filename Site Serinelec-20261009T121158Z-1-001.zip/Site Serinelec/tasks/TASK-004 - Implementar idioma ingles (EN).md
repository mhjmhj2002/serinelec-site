﻿REGRAS DE EXECUÇÃO ATUALIZADAS (09/10/2026) — PRIORIDADE SOBRE INSTRUÇÕES ANTIGAS:
Ler AGENTS.md no projeto/Drive e README.md da raiz antes de executar. Trabalhar exclusivamente na branch atual. NÃO executar git commit, git push, checkout, switch, merge, rebase, deploy nem GitHub Actions; deixar alterações locais para revisão e publicação pelo Owner. Trechos abaixo que determinem commit/push/deploy ficaram SUPERADOS por esta regra. Status permanece PENDENTE até execução e validação reais.
AGENTS.md: https://drive.google.com/file/d/1B13PKY1cAutkQq7eZHx_98ewxSaUz9St/view
README.md: https://github.com/mhjmhj2002/serinelec-site/blob/main/README.md


TASK-004 — Implementar versão completa em inglês (EN)
Projeto: Site Serinelec — https://preview.serinelec.cl/
Prioridade: P1 — planejada para evolução pré-produção
Status: PENDENTE | Execução: NÃO INICIADA | Progresso: 0%
Data de cadastro: 09/10/2026
Repositório: https://github.com/mhjmhj2002/serinelec-site
Projeto local: /home/mhj/git/serinelec-site


1. OBJETIVO
Adicionar versão integral em inglês profissional ao site institucional da empresa chilena Serinelec. Manter Espanhol (Chile, es-CL) original e Português (Brasil, pt-BR) da TASK-003. A versão inglesa deve existir em HTML estático indexável, sem dependência de frameworks, Node ou serviços externos de tradução.


2. DEPENDÊNCIA E COMPATIBILIDADE
Esta task depende da definição da estratégia estática de idiomas da TASK-003 e deve reutilizá-la em vez de criar nova arquitetura. Verificar o estado real da TASK-003 antes de implementar; se ainda não executada, coordenar a decisão de rotas e seletor, sem inventar arquivos ou marcar pendências como concluídas.
Fonte editorial principal: os textos es-CL da Serinelec, não uma tradução intermediária do português, evitando perda de precisão.


3. ESTRATÉGIA E ESCOPO
Preferir seis páginas sob /en/: /en/index.html, /en/capacitaciones.html, /en/gestion-produccion.html, /en/inspecciones.html, /en/proyectos-electricos.html e /en/contacto.html; seguir convenção estabelecida na TASK-003. Manter as URLs principais es-CL na raiz e pt-BR em /pt-br/.
Compartilhar assets CSS JS do site, adequando caminhos relativos para scripts, imagens, favicon e navegação. Cada página deve conter seu conteúdo no HTML, sem renderização JS obrigatória.


4. TRADUÇÃO PROFISSIONAL
Traduzir integralmente o conteúdo das seis páginas: cabeçalho, menus, mobile drawer, hero e carrossel, cartões, serviços, clientes, textos institucionais, depoimentos apenas se forem reais, CTAs, contato, formulário, placeholders, mensagens de erro/feedback, rodapé, títulos, descrições SEO e acessibilidade (alt/aria/title).
Inglês claro, corporativo e natural para clientes internacionais de serviços industriais/engenharia elétrica; evitar expressões literais e jargão comercial artificial.
Preservar nomes de empresas/clientes, endereço/telefone chileno, referências ao Chile e termos técnicos chilenos (SEC, TE1, ITO etc.), podendo explicar brevemente as siglas quando necessário, sem afirmar equivalência de normas estrangeiras.
Não inventar qualificações, clientes, casos, certificações, números, atendimento em países não confirmados, orçamento gratuito ou garantias comerciais. CTAs como “Request a Quote” sem prometer custo zero.


5. SELETOR / UX / RESPONSIVIDADE
Habilitar EN de fato no desktop e mobile/hamburger, sem manter rótulo “Coming soon” para a versão inglesa concluída. ES/PT também funcionais se suas tarefas estiverem implantadas. Indicar idioma selecionado corretamente em cada versão e preservar correspondência da página ao trocar de idioma. HTML lang="en" (inglês internacional) para páginas traduzidas; não pressupor mercado exclusivamente EUA só por usar 🇺🇸 no seletor. Padronizar apresentação dos idiomas para não confundir nacionalidade com idioma.
Manter os ajustes da TASK-002: sem sobreposição no carrossel, idioma no menu mobile, menu nas cores do site e telefone acessível, CTAs centralizados. Traduzir respeitando tamanho dos textos em celular sem overflow horizontal ou clipping.


6. SEO E METADADOS
Título e descrição específicos em inglês para cada página, links canonical corretos, hreflang es-CL/pt-BR/en e x-default quando fizer sentido, apenas para URLs já existentes. Evitar conteúdos duplicados entre idiomas marcados incorretamente; preservar semântica e legibilidade. Não redirecionar automaticamente visitantes por IP.


7. FORMULÁRIO
Integrar a UI inglesa ao mesmo formulário seguro existente da TASK-001 quando esta estiver concluída, sem duplicar endpoint PHP ou segredos. Se o backend ainda não estiver ativo, manter aviso honesto na página inglesa. A configuração do servidor não deve ser alterada sem aprovação do Owner.
Traduzir mensagens de validação e confirmação reais. Preservar comportamento seguro do envio.


8. DEPLOY
O workflow GitHub Actions já publica preview via cPanel UAPI. Garantir que /en/** esteja incluída nos arquivos elegíveis para upload e que arquivos do site estático sejam publicados no diretório correto. Não enviar documentação, backups, .git, .local, credenciais ou segredos. Nunca alterar produção serinelec.cl ou usar exclusão automática.


9. CRITÉRIOS DE ACEITE
Seis páginas completas em inglês; nenhuma seção residual em espanhol/português fora de nomes próprios/termos técnicos.
Seletor ES/EN/PT funciona sem links quebrados, desktop e mobile, e retorna à página correspondente.
Layout responsivo e acessível, CTAs e carrossel corretos, metadados de idioma adequados, fotos preservadas.
Conteúdo fiel e profissional; sem criação de informações comerciais não verificadas.
Sem Node/React/Vite/build ou biblioteca de tradução; sem Playwright, Cypress, Puppeteer, Selenium, E2E ou screenshots automatizados. Apenas inspeções estáticas e homologação manual.
Implementação somente quando autorizada; comitar, push e validar deploy no preview quando realizado. Conclusão somente após validação do Owner.


10. ENTREGA / ESTADO
Documento cadastrado para execução futura, ainda com 0% de progresso. Registrar arquivos alterados, páginas, decisões de tradução, confirmação de deploy e pendências quando ocorrer execução. Atualizar ANDAMENTO_MELHORIAS sem antecipar status.